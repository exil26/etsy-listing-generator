# Etsy Listing Generator

This Streamlit app lets you generate SEO-optimized Etsy product listings using a MindPal multi-agent AI workflow.

## How to Use
1. Upload this project to GitHub
2. Deploy on [Streamlit Cloud](https://streamlit.io/cloud)
3. Add your MindPal API key in Streamlit Secrets

## Secrets Format
```
API_KEY = "your_mindpal_api_key"
```
